#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <ctype.h>
#include "fragment.h"
#include "AT_skew_aux.h"
#include "allocate.h"
//#include "Ori_seq_analysis.h"

int EXAMINE_doublet=0; // Examine doublets?
int print_GG=1;   //
int print_AA=0;
int LOOP=3;       // 
int store_GG=0;     // 0= only GGN 1=GGN and GG
//int GGNmin=2, GGNmin_max=4, GGNmin_step=4;
int GGNmin=4, GGNmin_max=20, GGNmin_step=4;
int AANmin=6, AANmin_max=10, AANmin_step=2; 
int AAN_thr=6; // Min. number of AAN for examining distances

int GGN_max=5000; // Maximum number of GGN triplets in a cluster

char Nuc_code[4]="ATGC";

static int Get_input(char **file_chr, char **chr_name, char *genome,
		     int NMAX, int *GGNmin, int *GGNmin_max, int *LOOP,
		     int *EXAMINE_doublet, int *store_GG,
		     int *print_GG, int *print_AA,
		     int argc, char **argv);
static void help(char *CODE);
static void Read_seq_mult(char **chromosome, long *Lchr,
			  int Nchr, char *name_in);
void Write_chromosome(char **chromosome, long *Lchr, int n,
		      long L_tmp, char *Seq_tmp);
static int Count_sequences(char *name_in);
int Closest_AAN(struct frag *f, struct frag **ini, int thr);

int Code_nuc(char s);
void Freq_nucs(double *fnuc, char *Seq, long L);
char Complement(char n);
void Read_name(int *n, char **file, char *PATH, char *string, int nmax);
void Order_peaks(struct frag *frag, int n, struct frag *f0);

int Analyze_GGN(long *Nclus_GGN, char N1, char N2, float thr, int loop,
		char **chromosome, long *Lchr, int Nchr, double *fnuc);
int Count_GGN(double *nuc3, long *N_GGN_l, long *norm_GGN_l, long *Identical, 
	      char *Seq, long L, int Loop_max, char X, char Y);
void Count_clusters_GGN(long *Nclus_GGN_l, int *n_max, 
			char *Seq, long L, int GGN_max, int l_opt,
			char X, char Y);
void Call_GGN_clusters(long *N_GGN, struct frag *GGN,
		       char *Seq, long L, int chr,
		       int LOOP, int GGNmin, char X, char Y, int strand);


int Analyze_XY(long *Nclus_XYN, char N1, char N2, float thr, int loop,
	       char **chromosome, long *Lchr, int Nchr, double *fnuc);
int Count_XY(long *N_XY_l, long *norm_XY_l,
	     char *Seq, long L, int Loop_max, char X, char Y);
void Count_clusters_GGN(long *Nclus_XY_l, int *n_max, 
			char *Seq, long L, int XY_max, int l_opt,
			char X, char Y);
void Call_GG_clusters(long *N_GGN, struct frag *GGN,
		      char *Seq, long L, int chr,
		      int Loop_max, int GGmin, int GGmax,
		      char X, char Y, int strand);

int main(int argc, char **argv)
{
  // Chromosomes
  int NMAX=100; char *file_chr[NMAX], *chr_name[NMAX], genome[100];

  // Read input names and parameters
  int Nchr=Get_input(file_chr, chr_name, genome, NMAX,
		     &GGNmin, &GGNmin_max, &LOOP,
		     &EXAMINE_doublet, &store_GG, &print_GG, &print_AA,
		     argc, argv);
  if(GGNmin_max<GGNmin)GGNmin_max=GGNmin;

  // Read chromosomes
  if(file_chr[0][0]=='\0'){
    printf("ERROR, file with chromosomes must be specified\n");
    exit(8);
  }

  int onefile=0, chr;
  if(Nchr==1){onefile=1; Nchr=Count_sequences(file_chr[0]);}

  char **chromosome=malloc(Nchr*sizeof(char *));
  long *Lchr=malloc(Nchr*sizeof(long)), Lmax=0;

  if(onefile){
    Read_seq_mult(chromosome, Lchr, Nchr, file_chr[0]);
  }else{
    for(chr=0; chr<Nchr; chr++){
      printf("Reading %s\n", file_chr[chr]);
      Lchr[chr]=Read_sequence(&(chromosome[chr]), file_chr[chr]);
    }
  }
  for(chr=0; chr<Nchr; chr++){
    chromosome[chr][Lchr[chr]]='\0';
    if(Lchr[chr]>Lmax)Lmax=Lchr[chr];
    if(onefile){
      chr_name[chr]=malloc(80*sizeof(char));
      sprintf(chr_name[chr], "%d", chr+1);
    }
  }

  int i, j; double fnuc[4]; for(i=0; i<4; i++)fnuc[i]=0;
  for(chr=0; chr<Nchr; chr++){
    Freq_nucs(fnuc, chromosome[chr], Lchr[chr]);
  }
  int Complementary[4]; // ATGC
  Complementary[0]=1; Complementary[1]=0; // AT
  Complementary[2]=3; Complementary[3]=2; // GC
  //for(i=0; i<4; i++)Complementary[i]=Code_nuc(Complement(Nuc_code[i]));

  float thr=1.16;
  int num=0, code_GGN=-1; long N_clus_GGN=0, N_clus_AAN=0;
  int done[16]; for(i=0; i<16; i++)done[i]=-1; //GG=2*4+2=10;
  for(i=0; i<4; i++){
    char n1=Nuc_code[i];
    for(j=0; j<4; j++){
      char n2=Nuc_code[j]; int code=4*i+j;
      if(done[code]>=0)continue;
      done[code]=1;
      int code2=4*Complementary[j]+Complementary[i]; done[code2]=1;
      long Nclus_XYN[GGN_max];
      num++; printf("%2d: Computing %c%cN  ", num, n1, n2);
      long N_clus=
	Analyze_GGN(Nclus_XYN, n1, n2, thr,LOOP,chromosome,Lchr,Nchr,fnuc);
      if((n1=='G')&&(n2=='G')){code_GGN=code; N_clus_GGN=N_clus;}
      else if((n1=='A')&&(n2=='A')){N_clus_AAN=N_clus;}
      printf("%2d: Computing %c%c  ", num, n1, n2);
      if(EXAMINE_doublet)
	Analyze_XY(Nclus_XYN, n1, n2, thr, LOOP, chromosome, Lchr, Nchr, fnuc);
    }
  }
  if(code_GGN<0){printf("ERROR, GGN not found\n"); exit(8);}

  printf("Calling GGN_clusters with max. loop = %d ", LOOP);
  printf("and min. number of GGN = %d\n", GGNmin);
  printf("Expected number of clusters: %ld\n", N_clus_GGN);
  
  long N_clus_max;
  struct frag *GGN_frag=NULL, *AAN_frag=NULL, ini_frag[2];
  int N_GGN=0, N_AAN=0;

  for(int ia=0; ia<=1; ia++){ // ia=0: AAN ia=1: GGN
    // Set parameters
    char n1, n2; struct frag *XXN_frag;
    int XXNmin, XXNmax, XXNstep, loop;
    if(ia==0){
      if(print_AA==0)continue;
      n1='A'; n2='T'; loop=0;
      N_clus_max=3*N_clus_AAN;
      AAN_frag=malloc(N_clus_max*sizeof(struct frag));
      if(AAN_frag==NULL){
	printf("ERROR, not enough memory for AAN clusters\n");
	exit(8);
      }
      XXN_frag=AAN_frag; 
      XXNmin=AANmin; XXNmax=AANmin_max; XXNstep=AANmin_step;
    }else{
      if(print_GG==0)continue;
      n1='G'; n2='C'; loop=LOOP;
      N_clus_max=N_clus_GGN; if(store_GG)N_clus_max*=3;
      GGN_frag=malloc(N_clus_max*sizeof(struct frag));
      if(GGN_frag==NULL){
	printf("ERROR, not enough memory for GGN clusters\n");
	exit(8);
      }
      XXN_frag=GGN_frag; 
      XXNmin=GGNmin; XXNmax=GGNmin_max; XXNstep=GGNmin_step;
    }

    //struct frag check=XXN_frag[0];
    struct frag *f0;
    int XXmin=XXNmin; 
    int XX3=(3*XXNmin), XXmax=XX3/2; if(XXmax*2==XX3){XXmax--;}

    // Look for clusters in all chromosomes
    long N_XXN_c=0; 
    for(int chr=0; chr<Nchr; chr++){
      struct frag *XXN_ini=XXN_frag+N_XXN_c; long N_XXN=0;
      Call_GGN_clusters(&N_XXN, XXN_ini, chromosome[chr], Lchr[chr],
			chr+1, loop, XXNmin, n1, n1, 1);
      Call_GGN_clusters(&N_XXN, XXN_ini, chromosome[chr], Lchr[chr],
			chr+1, loop, XXNmin, n2, n2, -1);
      if(store_GG || ia==0){
	Call_GG_clusters(&N_XXN, XXN_ini, chromosome[chr], Lchr[chr],
			 chr+1, loop, XXmin, XXmax, n1, n1, 1);
	Call_GG_clusters(&N_XXN, XXN_ini, chromosome[chr], Lchr[chr],
			 chr+1, loop, XXmin, XXmax, n2, n2, -1);
      }
      if(N_XXN_c+N_XXN > N_clus_max){
	printf("ERROR, too many GGN clusters (more than %ld)\n", N_clus_max);
	exit(8);
      }
      if(N_XXN_c){f0=XXN_ini-1;}else{f0=&ini_frag[ia];}
      Order_peaks(XXN_ini, N_XXN, f0);
      N_XXN_c+=N_XXN;
      printf("%ld %c%cN clusters found\n", N_XXN_c, n1, n1);
    }

    struct frag *f=ini_frag[ia].next;
    while(f){f->x0=(f->ini+f->end)/2; f=f->next;}
    int d_GGN_AAN[N_XXN_c];
    if(ia==0){
      N_AAN=N_XXN_c;
    }else{
      N_GGN=N_XXN_c;
      if(N_AAN){
	struct frag *fG=ini_frag[1].next; // GGN
	struct frag *fA=ini_frag[0].next; // AAN;
	int i=0;
	while(fG){
	  d_GGN_AAN[i]=Closest_AAN(fG, &fA, AAN_thr);
	  fG=fG->next; i++;
	  if(i>N_GGN){printf("WARNING, > %d distances\n", i); break;}
	}
      }
    }

    char name_file[200], XX[3]; XX[0]=n1; XX[1]=n1; XX[2]='\0';
    printf("Loop from %d to %d, step %d\n", XXNmin, XXNmax, XXNstep);
    for(int XXNm=XXNmin; XXNm<=XXNmax; XXNm+=XXNstep){
      if(store_GG || ia==0){sprintf(name_file, "%sN+%s_clusters", XX, XX);}
      else{sprintf(name_file, "%sN_clusters", XX);}
      char tmp[150];
      sprintf(tmp, "_%s_Lmax_%d_%sNmin_%d.bed", genome, loop, XX, XXNm);
      strcat(name_file, tmp);
      FILE *file_out=fopen(name_file, "w");
      printf("Writing %sN_clusters in %s\n", XX, name_file);
      FILE *file_out2=NULL;
      if(N_GGN && N_AAN){
	sprintf(name_file, "GGN-AAN_distances_%s_Lmax_%d_GGNmin_%d.dat",
		genome, loop, XXNm);
	file_out2=fopen(name_file, "w");
	printf("Writing %ld %sN_clusters in %s\n", N_XXN_c, XX, name_file);
	fprintf(file_out2,"# distance between %d GGN clusters and ", N_GGN);
	fprintf(file_out2,"closest %d AAN cluster with AAN >=%d\n",
		N_AAN, AAN_thr);
      }
      struct frag *f=ini_frag[ia].next; int n=0;
      for(int i=0; i<N_XXN_c; i++){
	if(f==NULL){printf("%d clusters printed\n", n); break;}
	if(f->value>=XXNm){
	  fprintf(file_out, "%s\t%ld\t%ld\t%.0f\t%c\n",
		  chr_name[f->chr-1], f->ini, f->end, f->value,
		  f->strand);
	  if(file_out2){fprintf(file_out2,"%d\n", d_GGN_AAN[i]);}
	  n++;
	}
	//printf("%d\t%d\t%ld\n", i, f->chr, f->ini);
	f=f->next;
      }
      fclose(file_out);
      if(file_out2)fclose(file_out2);
    }
  } // end ia

  return(0);
}  

static int Get_input(char **file_chr,  char **chr_name, char *genome,
		     int NMAX, int *GGNmin, int *GGNmin_max, int *LOOP,
		     int *EXAMINE_doublet, int *store_GG,
		     int *print_GG, int *print_AA,
		     int argc, char **argv)
{
 if(argc<2)help(argv[0]);
  FILE *file_in=fopen(argv[1], "r");
  if(file_in==NULL){
    printf("ERROR, file %s not found\n", argv[1]); exit(8);
  }
  printf("Reading %s\n", argv[1]);

  char string[1000], PATH[80], dumm[80]; PATH[0]='\0';
  int nch=0, rch=-1; // Chromosomes
  int npk=0, rpk=-1; // peaks
  int idum=0;
  while(fgets(string, sizeof(string), file_in)!=NULL){
    if(string[0]=='#'){continue;
    }else if(strncmp(string, "GENOME", 6)==0){
      sscanf(string+7, "%s", genome);
    }else if(strncmp(string, "LOOP", 4)==0){
      sscanf(string+5, "%d", LOOP);
    }else if(strncmp(string, "GGNmin", 6)==0){ // Min value of GGNmin
      sscanf(string+7, "%d", &idum);
      if(idum < 4){
	printf("WARNING, wrong score, using default\n");
      }else{
	*GGNmin=idum;
      }
    }else if(strncmp(string, "GGNmax", 6)==0){
      sscanf(string+7, "%d", GGNmin_max); // Max value of GGNmin
    }else if(strncmp(string, "Examine_doublet", 15)==0){
      sscanf(string+16, "%d", EXAMINE_doublet);
    }else if(strncmp(string, "print_GG", 8)==0){
      sscanf(string+9, "%d", print_GG); // Print GGN?
    }else if(strncmp(string, "print_AA", 8)==0){
      sscanf(string+9, "%d", print_AA); // Print AAN?
    }else if(strncmp(string, "store_GG", 8)==0){
      sscanf(string+9, "%d", store_GG); // Store GGN+GG?

    }else if(strncmp(string, "CHROMOSOMES", 10)==0){
      printf("Reading chromosome names\n");
      rch=0;
    }else if(strncmp(string, "PEAKS", 5)==0){
      rpk=0;
    }else if(strncmp(string, "END", 3)==0){
      PATH[0]='\0'; 
      rch=-1; rpk=-1;
    }else if(strncmp(string, "DIR", 3)==0){
      char *s=string+4; int k=0;
      while(*s!='\n'){PATH[k]=*s; k++; s++;}
      PATH[k]='\0';
    }else if(rpk>=0){
      sscanf(string, "%s", dumm); npk++;
      //sprintf(file_peak, "%s%s", PATH, dumm);
    }else if(rch>=0){
      chr_name[nch]=malloc(80*sizeof(char));
      sscanf(string, "%s %s", dumm, chr_name[nch]);
      if(chr_name[nch][0]=='\0')sprintf(chr_name[nch], "%d", nch+1);
      Read_name(&nch, file_chr, PATH, string, NMAX);
    }else if(string[0]!='\n'){
      printf("WARNING, unrecognized command %s\n", string);
    }
  }
  fclose(file_in);
  printf("%d chromosomes to read:\n", nch);
  for(int i=0; i<nch; i++)printf("%s %s\n", chr_name[i], file_chr[i]);
  return(nch);
}

int Count_sequences(char *name_in){
  FILE *file_in=fopen(name_in, "r");
  if(file_in==NULL){
    printf("ERROR, file %s not found\n", name_in); exit(8);
  }
  printf("Reading %s\n", name_in);
  char string[1000]; int n=0;
  while(fgets(string, sizeof(string), file_in)!=NULL){
    if(string[0]=='>')n++;
  }
  if(n==0)n=1;
  return(n);
}

void Read_seq_mult(char **chromosome, long *Lchr, int Nchr, char *name_in){
  FILE *file_in=fopen(name_in, "r");
  if(file_in==NULL){
    printf("ERROR, file %s not found\n", name_in); exit(8);
  }
  printf("Reading %s\n", name_in);
  long LMAX=2000000000; char Seq_tmp[LMAX];
  char string[1000], *chr; int n=0; long L_tmp=0;
  while(fgets(string, sizeof(string), file_in)!=NULL){
    if((string[0]=='>')||(n==0)){
      if(n>=Nchr){
	printf("ERROR, too many chromosomes > %d\n", Nchr); exit(8);
      }
      // Start reading chromosome
      if(n)Write_chromosome(chromosome, Lchr, n-1, L_tmp, Seq_tmp);
      chr=Seq_tmp; L_tmp=0; n++;
      if((string[0]!='>')&&(string[0]!='#')){
	char *s=string; while(*s!='\n'){*chr=*s; s++; chr++; L_tmp++;}
      }
    }else if(string[0]!='#'){
      char *s=string; while(*s!='\n'){*chr=*s; s++; chr++; L_tmp++;}
      if(L_tmp>=LMAX){
	printf("ERROR, chromosome %d contains > %ld bases\n", n, LMAX);
	exit(8);
      }
    }
  }
  Write_chromosome(chromosome, Lchr, n-1, L_tmp, Seq_tmp);
}

void Write_chromosome(char **chromosome, long *Lchr, int n,
		      long L_tmp, char *Seq_tmp)
{
  chromosome[n]=malloc((L_tmp+1)*sizeof(char));
  char *chr=chromosome[n];
  for(int i=0; i<L_tmp; i++){*chr=*Seq_tmp; chr++; Seq_tmp++;}
  *chr='\0';
  Lchr[n]=L_tmp;
}

static void help(char *CODE){
  printf("\nPROGRAM %s\n", CODE);
  printf("Author: Ugo Bastolla <ubastolla@cbm.csic.es>,\n"
	 "Centro de Biologia Molecular Severo Ochoa"
	 "(CSIC-UAM), Madrid Spain\n\n"
	 "For an input genome in FASTA format, %s finds all clusters "
	 "containing at least <GGNmin> triplets of bases GGN separated by "
	 "at most <LOOP> intermediate residues.\n"
	 "It prints the coordinates of the GGN clusters in bed files.\n"
	 "For all dinucleotides XYN, where N is any nucleotide, it computes "
	 "the conditional probability to find two XYN triplets at distance d "
	 "and the conditional probability that the two nucleotides N are "
	 "identical, and it prints them in text files Cond_prob_XYN.dat\n\n", 
	 CODE);
  printf("USAGE: %s Input_GGN_clusters\n", CODE);
  printf("FORMAT of the configuration file Input_GGN_clusters:\n"
	 "LOOP=<>    ! Max. distance between GGN triplets\n"
	 "GGNmin=<>  ! Min. number of GGN to call a cluster\n"
	 "GGNmax=<>  ! Max of min. number of GGN to call a cluster\n"
	 "store_GG=<0,1> ! 1=Find both triplets GGN and doublets GG\n"
	 "Examine_doublet=<0,1> ! 1=Examine both triplets GGN and doublets GG\n"
	 "print_AA=<0,1> ! 1=Find also triplets AAN and doublets AA\n"
	 "print_GG=<0,1> ! 1=Print GGN (default)\n"
	 "CHROMOSOMES:\n"
	 "DIR=<>  Directory with chromosome sequences\n"
	 "<>      Files with chromosomes\n"
	 "END\n"
	 "\n");
  exit(8);
}

void Read_name(int *n, char **file, char *PATH, char *string, int nmax)
{
  if(*n>nmax){
    printf("ERROR, too many input files, maximum %d\n", nmax);
    exit(8);
  }
  char name[200]; sscanf(string, "%s", name);
  file[*n]=malloc(200*sizeof(char));
  sprintf(file[*n], "%s%s", PATH, name);
  (*n)++;
}

int Count_GGN(double *nuc3, long *N_GGN_l, long *norm_GGN_l, long *Identical,
	      char *Seq, long L, int Loop_max, char X, char Y)
{
  long L3=L-3; int N_GGN=0;
  for(long ini=0; ini<L; ini++){
    char *s=Seq+ini; 
    if((*s!=X)||(*(s+1)!=Y))continue;
    N_GGN++; char n3=*(s+2); nuc3[Code_nuc(n3)]++;
    int first=1;
    int l=0; long i=ini+3; s=Seq+i;
    while((l<Loop_max)&&(i<=L3)){
      norm_GGN_l[l]++;
      if((*s==X)&&(*(s+1)==Y)){
	N_GGN_l[l]++;
	if(first){if(*(s+2)==n3)Identical[l]++; first=0;}
	//l+=3; s+=3; i+=3; 
	break;
      }else{
	l++; s++; i++; 
      }
    }
  }
  return(N_GGN);
}

void Count_clusters_GGN(long *Nclus_GGN_l, int *n_max, 
			char *Seq, long L, int GGN_max, int loop,
			char X, char Y)
{
  long L3=L-3;
  for(long ini=0; ini<L; ini++){
    char *s=Seq+ini; 
    if((*s!=X)||(*(s+1)!=Y))continue;
    int l=0, GGN=1; long i=ini+3; s+=3;
    while((l<=loop)&&(i<=L3)){
      if((*s==X)&&(*(s+1)==Y)){
	GGN++; l=0; s+=3; i+=3; 
      }else{
	l++; s++; i++;
      }
    } // end loop of l
    if(GGN>*n_max)*n_max=GGN;

    if(GGN>=GGN_max){
      printf("WARNING, too many %c%cN motifs(%d>%d) loop= %d\n",
	     X, Y, GGN, GGN_max-1, l);
    }else{
      Nclus_GGN_l[GGN]++;
    }
    ini=i;
  }
}


int Count_XY(long *N_XY_l, long *norm_XY_l,
	     char *Seq, long L, int Loop_max, char X, char Y)
{
  long L2=L-2; int N_XY=0;
  char *s_ini=Seq; 
  for(long ini=0; ini<L; ini++){
    if((*s_ini==X)&&(*(s_ini+1)==Y)){
      N_XY++;
      // next XY at distance l
      int l=0; long i=ini+2; char *s=s_ini+2;
      while((l<Loop_max)&&(i<=L2)){
	norm_XY_l[l]++;
	if((*s==X)&&(*(s+1)==Y)){
	  N_XY_l[l]++;
	  break;
	}else{
	  l++; s++; i++; 
	}
      }
    }
    s_ini++;
  }
  return(N_XY);
}

void Count_clusters_XY(long *Nclus_XY_l, int *n_max, 
			char *Seq, long L, int XY_max, int l_max,
			char X, char Y)
{
  long L2=L-2;
  char *s_ini=Seq; 
  for(long ini=0; ini<L; ini++){
    if((*s_ini==X)&&(*(s_ini+1)==Y)){
      int l=0, XY=1; long i=ini+2; char *s=Seq+i;
      while((l<=l_max)&&(i<=L2)){
	if((*s==X)&&(*(s+1)==Y)){
	  XY++; l=0; s+=2; i+=2; 
	}else{
	  l++; s++; i++;
	}
      } // end loop of l
      if(XY>*n_max)*n_max=XY;
      if(XY>=XY_max){
	printf("WARNING, too many %c%c motifs(%d>%d) loop= %d\n",
	       X, Y, XY, XY_max-1, l);
      }else{
	Nclus_XY_l[XY]++;
      }
      ini=i;
    }
    s_ini++;
  }
}


void Call_GGN_clusters(long *N_GGN, struct frag *GGN,
		       char *Seq, long L, int chr,
		       int Loop_max, int GGNmin, char X, char Y, int st)
{
  struct frag *f=GGN+(*N_GGN);
  long L3=L-3, ini=0;
  while(ini<L3){
    char *s=Seq+ini; 
    if((*s!=X)||(*(s+1)!=Y)){ini++; continue;}
    int l=0, GGN=1; long i=ini+3, end=ini+2; s+=3;
    while((l<=Loop_max)&&(i<=L3)){
      if((*s==X)&&(*(s+1)==Y)){
	GGN++; l=0; s+=3; i+=3; end=i+2;
      }else{
	l++; s++; i++; 
      }
    }
    if(GGN >= GGNmin){
      f->chr=chr; f->ini=ini; f->end=end; f->value=GGN;
      if(st>0){f->strand='+';}else{f->strand='-';}
      f++; (*N_GGN)++; ini=end+1;
    }else{
      ini++;
    }
  }
}


void Call_GG_clusters(long *N_GGN, struct frag *GGN,
		      char *Seq, long L, int chr,
		      int Loop_max, int GGmin, int GGmax,
		      char X, char Y, int st)
{
  struct frag *f=GGN+(*N_GGN);
  long L2=L-2, ini=0;
  while(ini<L2){
    char *s=Seq+ini; 
    if((*s!=X)||(*(s+1)!=Y)){ini++; continue;}
    int l=0, GG=1; long i=ini+2, end=ini+1; s+=2;
    while((l<=Loop_max)&&(i<=L2)){
      if((*s==X)&&(*(s+1)==Y)){
	GG++; l=0; s+=2; i+=2; end=i+1;
      }else{
	l++; s++; i++; 
      }
    }
    if((GG >= GGmin)&&(GG <= GGmax)){
      f->chr=chr; f->ini=ini; f->end=end; f->value=GG;
      if(st>0){f->strand='+';}else{f->strand='-';}
      f++; (*N_GGN)++; ini=end+1;
    }else{
      ini++;
    }
  }
}

void Order_peaks(struct frag *frag, int n, struct frag *f0)
{
  f0->next=frag;
  struct frag *f1=frag, *f2=f1+1;
  for(int i=0; i<n; i++){f1->next=NULL; f1++;}
  f1=frag;
  for(int i=1; i<n; i++){
    if(f1->end >= f2->ini){
      f1=f0->next;
      if(f1->end >= f2->ini){ // First fragment of chromosome
	/*printf("First peak chr %d: %ld -> ", f1->chr, f1->ini);
	  printf("%d %ld %ld\n", f2->chr, f2->ini, f2->end);*/
	f0->next=f2; f2->next=f1; f2++; continue;
      }
    } 
    while((f1->next)&&(f1->next->end < f2->ini))f1=f1->next;
    f2->next=f1->next; f1->next=f2; 
    f1=f2; f2++;
  }
}

int Analyze_GGN(long *Nclus_GGN, char N1, char N2, float thr, int loop,
		char **chromosome, long *Lchr, int Nchr, double *fnuc)
{
  char M1=Complement(N1), M2=Complement(N2);

  // Statistics of loops
  int Loop_max=60, l, i;
  long N_GGN_l[Loop_max], norm_GGN_l[Loop_max];
  long Identical[Loop_max];
  for(l=0; l<Loop_max; l++){
    N_GGN_l[l]=0; norm_GGN_l[l]=0; Identical[l]=0;
  }
  double nuc3[4]; for(i=0; i<4; i++)nuc3[i]=0;

  // Clusters
  int n_max=0;
  for(i=0; i<GGN_max; i++)Nclus_GGN[i]=0;

  // Main counters
  int nm=1; // number of types of motifs
  long N_win3=0; // Possible windows for GGN or CCN
  long N_GGN=0;
  // expected frequency
  double f_exp=0;

  for(int c=0; c<Nchr; c++){
    N_win3+=(Lchr[c]-2);
    if(c==0)f_exp+=fnuc[Code_nuc(N1)]*fnuc[Code_nuc(N2)];
    N_GGN+=Count_GGN(nuc3, N_GGN_l, norm_GGN_l, Identical,
		     chromosome[c], Lchr[c], Loop_max, N1, N2);
    Count_clusters_GGN(Nclus_GGN, &n_max, chromosome[c], Lchr[c],
		       GGN_max, loop, N1, N2);

    if((M1!=N2)||(M2!=N1)){
      if(c==0){f_exp+=fnuc[Code_nuc(M1)]*fnuc[Code_nuc(M2)]; nm++;}
      N_GGN+=Count_GGN(nuc3, N_GGN_l, norm_GGN_l, Identical,
		       chromosome[c], Lchr[c], Loop_max, M2, M1);
      Count_clusters_GGN(Nclus_GGN, &n_max, chromosome[c], Lchr[c],
			 GGN_max, loop, M1, M2);
    }
  }

  char GGN[4]; GGN[0]=N1; GGN[1]=N2; GGN[2]='N'; GGN[3]='\0';
  char nameout[100]; sprintf(nameout, "Cond_prob_%s.dat", GGN);
  FILE *file_out=fopen(nameout, "w");
  printf("Writing %s\n", nameout);
  fprintf(file_out, "# Nucleotide frequencies: ");
  for(i=0; i<4; i++)fprintf(file_out, " %c %.3f", Nuc_code[i], fnuc[i]);
  fprintf(file_out, "\n");
  fprintf(file_out, "# Frequency of 3rd nucleotide: ");
  double sum=0; for(i=0; i<4; i++)sum+=nuc3[i];
  double P2=0;
  for(i=0; i<4; i++){
    nuc3[i]/=sum; fprintf(file_out, " %c %.3f", Nuc_code[i], nuc3[i]);
    P2+=nuc3[i]*nuc3[i];
  }
  fprintf(file_out, "\n");
  // Expected frequency
  double f_all=N_GGN/(double)N_win3;
  fprintf(file_out, "# Frequency of %s and %d complementary motifs: ",GGN, nm);
  fprintf(file_out, "%.5f Expected: %.5f\n", f_all, f_exp);
  double f_GGN=N_GGN/(double)(nm*N_win3);
  fprintf(file_out, "# Frequency of %s motif: %.5f Expected: %.5f\n",
	  GGN, f_GGN, f_exp/nm);

  fprintf(file_out, "# l P(%s|l) P(%s|l)/P(%s) P(identical|l)/P(identical)\n",
	  GGN, GGN, GGN);
  int l_opt=-1, l_thr=0, m=0;
  float f_thr=f_GGN*thr;
  for(l=0; l<Loop_max; l++){
    if(norm_GGN_l[l]==0)break;
    float fl=N_GGN_l[l]/(float)norm_GGN_l[l];
    fprintf(file_out, "%d  %.4f  %.4f  %.4f\n",
	    l, fl, fl/f_GGN, ((float)Identical[l]/N_GGN_l[l])/P2);
    if(fl<f_thr){ m++; if((m>=3)&&(l_opt<0))l_opt=l_thr;}
    else{m=0; l_thr=l;}
  }
  if(l_opt<0)l_opt=l_thr;

  fprintf(file_out, "# Maximum value of l: P(%s|l)>%.2fP(%s): %d\n",
	  GGN, thr, GGN, l_opt);
  fprintf(file_out, "# Probability of identical n3: %.4f se= %.4f\n",
	  P2, sqrt(P2/sum));
  double Id_low=0, Id_high=0, norm_low=0, norm_high=0;
  for(l=0; l<Loop_max; l++){
    if(l<=l_opt){Id_low+=Identical[l]; norm_low+=N_GGN_l[l];}
    else{Id_high+=Identical[l]; norm_high+=N_GGN_l[l];}
  }
  Id_low/=norm_low; float se=sqrt(Id_low*(1-Id_low)/norm_low);
  fprintf(file_out, "# P(identical|l<=%d)= %.4f s.e.= %.4f\n",
	  l_opt, Id_low, se);
  Id_high/=norm_high; se=sqrt(Id_high*(1-Id_high)/norm_high);
  fprintf(file_out, "# P(identical|l>%d)= %.4f s.e.= %.4f\n",
	  l_opt, Id_high, se);
  fclose(file_out);

  printf("Maximum l such that P(%s|l)> %.2f P(%s)= %d\n",
	 GGN, thr, GGN, l_opt);
  if(l_opt<0){printf("WARNING, l_opt<0\n"); l_opt=0;} //exit(8);

  // Print number of clusters
  printf("Maximum value of %s with loop<= %d: %d\n", GGN, loop, n_max);
  sprintf(nameout, "Clusters_%s.dat", GGN);
  file_out=fopen(nameout, "w");
  printf("Writing %s\n", nameout);
  fprintf(file_out, "# Joining %s motifs at distance <= %d\n", GGN,loop);
  int clus_max=0, n;
  for(n=1; n<=n_max; n++){
    if(Nclus_GGN[n]>clus_max){
      clus_max=Nclus_GGN[n]; //n_opt=n;
    }
    if(Nclus_GGN[n]==0)continue;
    fprintf(file_out, "%d %ld\n", n, Nclus_GGN[n]);
  }
  fclose(file_out);

  int N_GGN_max=0;
  for(n=GGNmin; n<=n_max; n++)N_GGN_max+=Nclus_GGN[n];
  return(N_GGN_max);

  return(l_opt);
}


int Analyze_XY(long *Nclus_XYN, char N1, char N2, float thr, int loop,
	       char **chromosome, long *Lchr, int Nchr, double *fnuc)
{
  char M1=Complement(N1), M2=Complement(N2);

  // Statistics of loops
  int Loop_max=40, l, i;
  long N_XY_l[Loop_max], norm_XY_l[Loop_max];
  for(l=0; l<Loop_max; l++){
    N_XY_l[l]=0; norm_XY_l[l]=0;
  }

  // Clusters
  int XY_max=1000, n_max=0; long Nclus_XY[XY_max];
  for(i=0; i<XY_max; i++)Nclus_XY[i]=0;

  // Main counters
  int nm=1; // number of types of motifs
  long N_win2=0; // Possible windows for GGN or CCN
  long N_XY=0;
  // expected frequency
  double f_exp=0;

  for(int c=0; c<Nchr; c++){
    N_win2+=(Lchr[c]-1);
    if(c==0)f_exp+=fnuc[Code_nuc(N1)]*fnuc[Code_nuc(N2)];
    N_XY+=Count_XY(N_XY_l, norm_XY_l, 
		   chromosome[c], Lchr[c], Loop_max, N1, N2);
    Count_clusters_XY(Nclus_XY, &n_max,
		      chromosome[c], Lchr[c], XY_max, loop, N1, N2);

    if((M1!=N2)||(M2!=N1)){
      if(c==0){f_exp+=fnuc[Code_nuc(M1)]*fnuc[Code_nuc(M2)]; nm++;}
      N_XY+=Count_XY(N_XY_l, norm_XY_l,
		     chromosome[c], Lchr[c], Loop_max, M2, M1);
      Count_clusters_XY(Nclus_XY, &n_max,
			chromosome[c], Lchr[c], XY_max, loop, M1, M2);
    }
  }

  char XY[3]; XY[0]=N1; XY[1]=N2; XY[2]='\0';
  char nameout[100]; sprintf(nameout, "Cond_prob_%s.dat", XY);
  FILE *file_out=fopen(nameout, "w");
  printf("Writing %s\n", nameout);
  fprintf(file_out, "# Nucleotide frequencies: ");
  for(i=0; i<4; i++)fprintf(file_out, " %c %.3f", Nuc_code[i], fnuc[i]);
  fprintf(file_out, "\n");
  // Expected frequency
  double f_all=N_XY/(double)N_win2;
  fprintf(file_out, "# Frequency of %s and %d complementary motifs: ",XY, nm);
  fprintf(file_out, "%.5f Expected: %.5f\n", f_all, f_exp);
  double f_XY=N_XY/(double)(nm*N_win2);
  fprintf(file_out, "# Frequency of %s motif: %.5f Expected: %.5f\n",
	  XY, f_XY, f_exp/nm);

  fprintf(file_out, "# l P(%s|l) P(%s|l)/P(%s)\n",
	  XY, XY, XY);
  int l_opt=-1, l_thr=0, m=0;
  float f_thr=f_XY*thr;
  for(l=0; l<Loop_max; l++){
    if(norm_XY_l[l]==0)break;
    float fl=N_XY_l[l]/(float)norm_XY_l[l];
    fprintf(file_out, "%d  %.4f  %.4f\n", l, fl, fl/f_XY);
    if(fl<f_thr){ m++; if((m>=3)&&(l_opt<0))l_opt=l_thr;}
    else{m=0; l_thr=l;}
  }
  if(l_opt<0)l_opt=l_thr;

  fprintf(file_out, "# Maximum value of l: P(%s|l)>%.2fP(%s): %d\n",
	  XY, thr, XY, l_opt);
  fclose(file_out);

  printf("Maximum l such that P(%s|l)> %.2f P(%s)= %d\n",
	 XY, thr, XY, l_opt);
  if(l_opt<0){printf("WARNING, l_opt<0\n"); l_opt=0;} //exit(8);

  // Print number of clusters
  printf("Maximum value of %s with loop<= %d: %d\n", XY, loop, n_max);
  sprintf(nameout, "Clusters_%s.dat", XY);
  file_out=fopen(nameout, "w");
  printf("Writing %s\n", nameout);
  fprintf(file_out, "# Clusters of %s motifs at distance <= %d\n", XY,loop);
  fprintf(file_out, "# num(%s) Clusters Clusters(%s)/Clusters(%sN)\n",
	  XY, XY, XY);
  int nthr=20, clus_max=0; float num=0;
  int nXY=0, nclus_2=0, nclus_3=0, n;
  for(n=1; n<GGN_max; n++){
    if(Nclus_XY[n]>clus_max)clus_max=Nclus_XY[n];
    num++; nXY+=n; 
    nclus_2+=Nclus_XY[n];
    nclus_3+=Nclus_XYN[n];
    if((nclus_2>=nthr)&&(nclus_3>=nthr)){
      fprintf(file_out, "%.1f\t%.0f\t%.3g\n",
	      nXY/num, nclus_2/num, nclus_2/(float)nclus_3);
      num=0; nXY=0; nclus_2=0; nclus_3=0;
    }
  }
  fclose(file_out);

  int N_XY_max=0;
  for(n=GGNmin; n<=n_max; n++)N_XY_max+=Nclus_XY[n];
  return(N_XY_max);

  //return(l_opt);
}


char Complement(char n){
  if(n=='A')return('T');
  if(n=='T')return('A');
  if(n=='G')return('C');
  if(n=='C')return('G');
  return('N');
}

void Freq_nucs(double *fnuc, char *Seq, long L){
  char *s=Seq; int i;
  long f[4]; for(i=0; i<4; i++)f[i]=0;
  while(*s!='\0'){i=Code_nuc(*s); if(i<4)f[i]++; s++;}
  double sum=0; for(i=0; i<4; i++)sum+=f[i];
  for(i=0; i<4; i++)fnuc[i]=f[i]/sum;
}

int Code_nuc(char s){
  for(int i=0; i<4; i++)if(s==Nuc_code[i])return(i);
  return(4);
}

int Closest_AAN(struct frag *f, struct frag **ini, int thr)
{
  struct frag *ff=*ini;
  long d_min=1000000;
  while(ff!=NULL){
    if((ff->chr==f->chr)&&(ff->value>=thr)){
      long d=abs(f->x0-ff->x0);
      if(d<d_min){d_min=d; *ini=ff;}else{break;}
    }else if(ff->chr>f->chr){
      break;
    }
    ff=ff->next;
  }
  if(d_min==1000000 || d_min==0){
    printf("ERROR f= %ld ini= %ld d= %ld\n", f->x0, (*ini)->x0, d_min);
    //exit(8);
  }
  return(d_min);
}
