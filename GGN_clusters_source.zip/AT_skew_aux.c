#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "fragment.h"
#include "AT_skew_aux.h"
static int Code_char(char nuc, char *code, int n);

//int Nsam_0=0;
long old_site=100000000;
long SUM_A1=0, SUM_T1=0, SUM_C1=0, SUM_G1=0; 
long SUM_A2=0, SUM_T2=0, SUM_C2=0, SUM_G2=0;
int STANDARD;

char name_motif[200];

static char Complementary(char nuc);
static void Sum_nuc(long *sum_A, long *sum_T, long *sum_G, long *sum_C,
	     char *seq, long j1, long j2);
static void Update_sum(long *sum_A, long *sum_T, long *sum_G, long *sum_C,
		       char *seq, long j1, long j2);
float AT_Skew(long sum_A1, long sum_T1, long n1,
		     long sum_A2, long sum_T2, long n2);
float GC_Skew(long sum_G1, long sum_C1, long n1,
		     long sum_G2, long sum_C2, long n2);
float GA_Skew(long sum_G1, long sum_C1, long n1,
		     long sum_G2, long sum_C2, long n2);
static float Skew(long sum_G1, long sum_C1,
		  long sum_G2, long sum_C2);
static float Diff_ave(float *s, long sum_A, long sum_T);
static float GC_Local(long sum_GC1, long n1,
		      long sum_GC2, long n2,
		      float GC, float dGC);
double Bino_dev(double p, double nsam);
static float Diff_norm(long sum_G, long sum_C);

long Read_sequence(char **seq, char *file_chr)
{
  long l=0;
  FILE *file_in=fopen(file_chr, "r");
  if(file_in==NULL){
    printf("ERROR, file %s not found\n", file_chr); exit(8);
  }
  char string[1000];
  while(fgets(string, sizeof(string), file_in)!=NULL){
    if(string[0]=='>')continue;
    l+=Count_char(string);
  }
  fclose(file_in);
  printf("%ld residues read in %s\n", l, file_chr);

  (*seq)=malloc((l+1)*sizeof(char)); l=0;
  file_in=fopen(file_chr, "r");
  while(fgets(string, sizeof(string), file_in)!=NULL){
    if(string[0]=='>')continue;
    l+=Copy_char(string, *seq+l);
  }
  (*seq)[l]='\0';
  fclose(file_in);
  return(l);
}

int Copy_char(char *string, char *seq){
  int n=0; char *s1=string, *s2=seq;
  while(*s1!='\n'){*s2=Maiuscule(*s1); s1++; s2++; n++;}
  return(n);
}

int Count_char(char *string){
  int n=0; char *s=string;
  while(*s!='\n'){s++; n++;}
  return(n);
}

char Maiuscule(char s){
  int i=(int)s;
  if(i>96){return((char)(i-32));}else{return(s);}
}

float GC_ave(char *seq, long L){
  long GC_sum=0, norm=L, i; char *s=seq;
  for(i=0; i<L; i++){
    if((*s=='G')||(*s=='C')){GC_sum++;}
    else if(*s=='N'){norm--;}
    s++;
  }
  return((float)GC_sum/(float)norm);
}

float Ave_nuc(char *seq, long L, char nuc){
  long sum=0, norm=L, i; char *s=seq;
  for(i=0; i<L; i++){
    if(*s==nuc){sum++;}
    else if(*s=='N'){norm--;}
    s++;
  }
  return((float)sum/(float)norm);
}

void Skew_comp(float *AT_skew, int *ATS_win,
	       float *GC_skew, int *GCS_win,
	       float *GA_skew, int *GAS_win,
	       float *GC_local,int *GCL_win,
	       char *seq, long L, long Win_ini,
	       long Win_max, float IND_FRAC,
	       float GC, float dGC, float dGCS, float dATS,
	       long site)
{
  float ATS_max, ATS; int ATS_W, ATS_comp=1;
  float GCS_max, GCS; int GCS_W, GCS_comp=1;
  float GAS_max, GAS; int GAS_W, GAS_comp=1;
  float GCL_max, GCL; int GCL_W, GCL_comp=1;

  // Start:
  long j11=site-Win_ini, j12=site;  if(j11<0)j11=0;
  long j21=site+1, j22=j21+Win_ini; if(j22>L)j22=L;
  if(site<old_site){
    printf("Starting chromosome\n");
    SUM_A1=0; SUM_T1=0; SUM_G1=0; SUM_C1=0;
    Sum_nuc(&SUM_A1, &SUM_T1, &SUM_G1, &SUM_C1, seq, j11, j12);
    SUM_A2=0; SUM_T2=0; SUM_G2=0; SUM_C2=0;
    Sum_nuc(&SUM_A2, &SUM_T2, &SUM_G2, &SUM_C2, seq, j21, j22);
  }else{
    Update_sum(&SUM_A1, &SUM_T1, &SUM_G1, &SUM_C1, seq, j11, j12);
    Update_sum(&SUM_A2, &SUM_T2, &SUM_G2, &SUM_C2, seq, j21, j22);
  }
  ATS_max=Skew(SUM_A1, SUM_T1, SUM_A2, SUM_T2);
  GCS_max=Skew(SUM_G1, SUM_C1, SUM_G2, SUM_C2);
  long sum_GC1=SUM_G1+SUM_C1, sum_GC2=SUM_G2+SUM_C2;
  long n1=SUM_A1+SUM_T1+SUM_C1+SUM_G1; 
  long n2=SUM_A2+SUM_T2+SUM_C2+SUM_G2;
  GAS_max=Skew(sum_GC1, n1-sum_GC1, sum_GC2, n2-sum_GC2);
  GCL_max=GC_Local(sum_GC1, n1, sum_GC2, n2, GC, dGC);
  ATS_W=n1+n2; GCS_W=ATS_W; GAS_W=ATS_W; GCL_W=ATS_W;
  old_site=site;


  if(Win_max>Win_ini){
    // Optimize window
    long sum_A1=SUM_A1, sum_T1=SUM_T1, sum_C1=SUM_C1, sum_G1=SUM_G1;
    long sum_A2=SUM_A2, sum_T2=SUM_T2, sum_C2=SUM_C2, sum_G2=SUM_G2;

    //if(Nsam_0==0)Nsam_0=Win_ini*IND_FRAC;
    
    while(1){
      j12=j11; j11-=Win_ini; if(j11<0)j11=0; //j11-=n1;
      if((site-j11)>=Win_max)break;
      j21=j22; j22+=Win_ini; if(j22>L)j22=L; //j22+=n2;
      if((j22-site)>=Win_max)break;
      Sum_nuc(&sum_A1, &sum_T1, &sum_G1, &sum_C1, seq, j11, j12);
      Sum_nuc(&sum_A2, &sum_T2, &sum_G2, &sum_C2, seq, j21, j22);
      n1=sum_A1+sum_T1+sum_C1+sum_G1; 
      n2=sum_A2+sum_T2+sum_C2+sum_G2;
      // Compute AT_skew
      if(ATS_comp){
	ATS=Skew(sum_A1, sum_T1, sum_A2, sum_T2);
	if(fabs(ATS)>fabs(ATS_max)){
	  ATS_max=ATS; ATS_W=n1+n2;
	}else{
	  ATS_comp=0;
	}
      }
      // Compute GC_skew
      if(GCS_comp){
	GCS=Skew(sum_G1, sum_C1, sum_G2, sum_C2);
	if(fabs(GCS)>fabs(GCS_max)){
	  GCS_max=GCS; GCS_W=n1+n2;
	}else{
	  GCS_comp=0;
	}
      }
      // Compute GA_skew
      if(GAS_comp){
	sum_GC1=sum_G1+sum_C1; sum_GC2=sum_G2+sum_C2; 
	GAS=Skew(sum_GC1, n1-sum_GC1, sum_GC2, n2-sum_GC2);
	if(fabs(GAS)>fabs(GAS_max)){
	  GAS_max=GAS; GAS_W=n1+n2;
	}else{
	  GAS_comp=0; 
	} 
      } 
      // Compute GC_local
      if(GCL_comp){
	sum_GC1=sum_G1+sum_C1; sum_GC2=sum_G2+sum_C2; 
	GCL=GC_Local(sum_GC1, n1, sum_GC2, n2, GC, dGC);
	if(fabs(GCL)>fabs(GCL_max)){
	  GCL_max=GCL; GCL_W=n1+n2;
	}else{
	  GCL_comp=0;
	}
      }
      // Exit?
      if(((GCL_comp==0)&&(GCS_comp==0)&&(GAS_comp==0) &&(ATS_comp==0))||
	 (j11==0)||(j22==L))break;
    }
  }
  //printf("%d  %d %d\n", site, j11, j22);
  AT_skew[site]= ATS_max; ATS_win[site]=ATS_W;
  GC_skew[site]= GCS_max; GCS_win[site]=GCS_W;
  GA_skew[site]= GAS_max; GAS_win[site]=GAS_W;
  GC_local[site]=GCL_max; GCL_win[site]=GCL_W;
}

void Print_skew_wig(float *score, int *window, long L, char *filename,
		    int WINOUT, char *name, char *chr)
{
  char nameout[400];
  //int skew=strncmp(name+3, "skew", 4);
  sprintf(nameout, "%s_%s.wig", filename, name);
  FILE *file_out=fopen(nameout, "w");
  printf("Writing %s\n", nameout);

  long i; //iwp=0, iwp_ini=0;
  int n=0; double sum=0, win_sum=0;
  fprintf(file_out, "fixedStep chrom=chr%s start=1 step=%d\n", chr, WINOUT);
  for(i=0; i<L; i++){
    n++; sum+=score[i]; win_sum+=window[i];
    if(n==WINOUT){
      fprintf(file_out, "%.2f\n", sum/n);
      n=0; sum=0; win_sum=0;
    }
  }
  fclose(file_out);
}


void Print_skew_bed(float *score, int *window, long L, char *filename,
		    int WINOUT, char *name, char *chr)
{
  char nameout[400];
  //int skew=strncmp(name+3, "skew", 4);
  sprintf(nameout, "%s_%s.bed", filename, name);
  FILE *file_out=fopen(nameout, "w");
  printf("Writing %s\n", nameout);
  long i, iwp=0, iwp_ini=0; int n=0; double sum=0, win_sum=0;
  //fprintf(file_out, "# site %s optimal_window\n", name);
  fprintf(file_out, "track type=bedGraph\n");
  for(i=0; i<L; i++){
    n++; sum+=score[i]; win_sum+=window[i];
    if(n==WINOUT){
      iwp+=WINOUT;
      fprintf(file_out, "chr%s\t%ld\t%ld\t%.1f\n",
	      chr, iwp_ini+1, iwp, sum/n);
      n=0; sum=0; win_sum=0; iwp_ini=iwp;
    }
  }
  fclose(file_out);
}


void Print_skew(float *score, int *window, long L, char *filename,
		int WINOUT, char *name)
{
  char nameout[400];
  //int skew=strncmp(name+3, "skew", 4);
  sprintf(nameout, "%s_%s.dat", filename, name);
  FILE *file_out=fopen(nameout, "w");
  printf("Writing %s\n", nameout);
  long i, iwp=0; int n=0; double sum=0, win_sum=0;
  //fprintf(file_out, "# site %s optimal_window\n", name);
  for(i=0; i<L; i++){
    n++; sum+=score[i]; if(window)win_sum+=window[i];
    if(n==WINOUT){
      fprintf(file_out, "%7ld %5.2f", iwp, sum/n);
      if(window){fprintf(file_out, " %.0f\n", win_sum/n); win_sum=0;}
      fprintf(file_out, "\n");
      n=0; sum=0; iwp+=WINOUT;
    }
  }
  fclose(file_out);
}


void Print_GC(char *seq, long L, char *filename, int WINOUT)
{
  char nameout[400];
  sprintf(nameout, "%s_GC.dat", filename);
  FILE *file_out=fopen(nameout, "w");
  printf("Writing %s\n", nameout);
  long i, iwp=1; int n=0; double sum=0;
  fprintf(file_out, "# site GC\n");
  for(i=0; i<L; i++){
    if((seq[i]=='G')||(seq[i]=='C'))sum++;
    n++;
    if(n==WINOUT){
      fprintf(file_out, "%7ld %.3f\n", iwp, sum/n);
      iwp+=WINOUT; n=0; sum=0;
    }
  }
  fclose(file_out);
}

void Print_nuc(char *seq, long L, char *filename, int WINOUT, char *nuc)
{
  char nameout[400];
  sprintf(nameout, "%s_%s.dat", filename, nuc);
  FILE *file_out=fopen(nameout, "w");
  printf("Writing %s\n", nameout);
  long i, iwp=1; int n=0; double sum=0;
  fprintf(file_out, "# site GC\n");
  for(i=0; i<L; i++){
    if(seq[i]==nuc[0])sum++;
    n++;
    if(n==WINOUT){
      fprintf(file_out, "%7ld %.3f\n", iwp, sum/n);
      iwp+=WINOUT; n=0; sum=0;
    }
  }
  fclose(file_out);
}



float Diff_ave(float *s, long sum_A, long sum_T){
  float w=sum_A+sum_T;
  if(w==0){*s=0; return(0);}
  float A=sum_A/w, d=2*A-1;
  //(*s)=(1.-d*d)/w;     // s**2(d)=4A(1-A)
  (*s)=(1.-d*d);     // s**2(d)=4A(1-A)
  if(*s<=0)(*s)=1./w;
  d/=(*s);
  return(d);
}


void Sum_nuc(long *sum_A, long *sum_T, long *sum_G, long *sum_C,
	     char *seq, long j1, long j2)
{
  char *s1=seq+j1; long j;
  for(j=j1; j<j2; j++){
    if(*s1=='A'){(*sum_A)++;}
    else if(*s1=='T'){(*sum_T)++;}
    else if(*s1=='G'){(*sum_G)++;}
    else if(*s1=='C'){(*sum_C)++;}
    s1++;
  }
}

void Update_sum(long *sum_A, long *sum_T, long *sum_G, long *sum_C,
		char *seq, long j1, long j2)
{
 char *s1=seq+j1-1;
 if(*s1=='A'){(*sum_A)--;}
 else if(*s1=='T'){(*sum_T)--;}
 else if(*s1=='G'){(*sum_G)--;}
 else if(*s1=='C'){(*sum_C)--;}
 s1=seq+j2-1;
 if(*s1=='A'){(*sum_A)++;}
 else if(*s1=='T'){(*sum_T)++;}
 else if(*s1=='G'){(*sum_G)++;}
 else if(*s1=='C'){(*sum_C)++;}
}

float GC_Local(long sum_GC1, long n1,
	       long sum_GC2, long n2,
	       float GC, float dGC)
{
  double nn=n1+n2;
  if(nn==0)return(0);
  double GC_local=(sum_GC1+sum_GC2)/nn;
  double sGC=dGC/sqrt(nn);
  // nsam=Nsam_0+IND_FRAC*nn;
  //double sGC=Bino_dev(GC_local, nsam);
  return((GC_local-GC)/sGC);
}

float Skew(long sum_G1, long sum_C1,
	   long sum_G2, long sum_C2)
{
  float skew;
  if(STANDARD){
    float G=sum_G1+sum_G2, C=sum_C1+sum_C2;
    if((G!=0)&&(C!=0)){skew=(G-C)/(C+G);}
    else{skew=0;}
  }else{
    skew=Diff_norm(sum_G2, sum_C2)-Diff_norm(sum_G1, sum_C1);
  }
  return(skew);
}

float Diff_norm(long sum_G, long sum_C){
  long w=sum_G+sum_C;
  if(w){return((sum_G-sum_C)/sqrt((float)w));} //
  else{return(0);}
}

///////////// Outdated

float Skew_old(long sum_G1, long sum_C1, long n1,
	       long sum_G2, long sum_C2, long n2)
{
  float s1, d1=Diff_ave(&s1, sum_G1, sum_C1);
  float s2, d2=Diff_ave(&s2, sum_G2, sum_C2);
  //if((s1<=0)&&(s2<=0))return(0);
  //float score=(d1-d2)/sqrt(s1+s2); return(score);
  return(d1-d2);
}


float AT_Skew(long sum_A1, long sum_T1, long n1,
	      long sum_A2, long sum_T2, long n2)
{
  float s1, d1=Diff_ave(&s1, sum_A1, sum_T1);
  float s2, d2=Diff_ave(&s2, sum_A2, sum_T2);
  //if((s1<=0)&&(s2<=0))return(0);
  //float score=(d1-d2)/sqrt(s1+s2); return(score);
  return(d1-d2);
}

float GC_Skew(long sum_G1, long sum_C1, long n1,
	      long sum_G2, long sum_C2, long n2)
{
  float s1, d1=Diff_ave(&s1, sum_G1, sum_C1);
  float s2, d2=Diff_ave(&s2, sum_G2, sum_C2);
  //if((s1<=0)&&(s2<=0))return(0);
  //float score=(d1-d2)/sqrt(s1+s2); return(score);
  return(d1-d2);
}

float GA_Skew(long sum_G1, long sum_C1, long n1, 
	      long sum_G2, long sum_C2, long n2)
{
  float GC1=(sum_G1+sum_C1);
  float GC2=(sum_G2+sum_C2);
  float s1, d1=Diff_ave(&s1, GC1, n1-GC1);
  float s2, d2=Diff_ave(&s2, GC2, n2-GC2);
  //if((s1<=0)&&(s2<=0))return(0);
  //float score=(d1-d2)/sqrt(s1+s2); return(score);
  return(d1-d2);
}


float GA_Skew_old(long sum_G1, long sum_C1, long n1, 
		  long sum_G2, long sum_C2, long n2)
{
  if((n1==0)||(n2==0))return(0);
  float GC1=(sum_G1+sum_C1)/(float)n1;
  float GC2=(sum_G2+sum_C2)/(float)n2;
  float s1=GC1*(1-GC1), s2=GC2*(1-GC2);
  if((s1<=0)&&(s2<=0))return(0);
  float score=(GC1-GC2)/sqrt(s1/n1+s2/n2);
  return(score);
}

double Bino_dev(double p, double nsam)
{
  if((p<=0)||(p>=1))return(1./nsam);
  return(sqrt(p*(1-p)/nsam));
}



long Find_motif(long *list, char *motif, char *seq, long L)
{
  char *s1=seq, *s2, *m1=motif, *m2; long i, n=0;
  for(i=0; i<L; i++){
    if(*s1==*m1){
      s2=s1+1; m2=m1+1;
      while(*m2!='\0'){if(*s2!=*m2)break; s2++; m2++;}
      if(*m2=='\0'){list[n]=i; n++;}
    }
    s1++;
  }
  return(n);
}

void Print_motif(long *list, long Nmot, char *filename, int cr,
		 char *motif, int len)
{
  long i; FILE *file_out;
  if(cr==1){
    sprintf(name_motif, "%s_%s.bed", filename, motif);
    file_out=fopen(name_motif, "w");
  }else{
    file_out=fopen(name_motif, "a");
  }
  printf("Writing %ld motifs %s in %s\n", Nmot, motif, name_motif);
  for(i=0; i<Nmot; i++){
    fprintf(file_out,"%d\t%ld\t%ld\t\n", cr, list[i]+1,list[i]+len+1);
  }
  fclose(file_out);
}

int Count_nuc(char *Seq, int L, char x){
  char *s=Seq; int num=0;
  for(int i=0; i<L; i++){if(*s==x)num++; s++;}
  return(num);
}

int Count_XYN(char *Seq, int len, char X, char Y){
  int GGX=0; char *s=Seq;
  int free[len]; for(int i=0; i<len; i++)free[i]=1;
  for(int i=0; i<(len-2); i++){
    if((*s==X)&&(*(s+1)==Y)&&(free[i])&&(free[i+1])){
      GGX++; free[i]=0; free[i+1]=0; free[i+2]=0;
    }
    s++;
  }
  return(GGX);
}

int Count_XYN_num(int *num, char *atgc, char *Seq, int len,
		  char X, char Y, int dir)
{
  int GGX=0; char *s=Seq; int i, a;
  for(a=0; a<4; a++)num[a]=0;
  int free[len]; for(i=0; i<len; i++)free[i]=1;
  for(i=0; i<(len-2); i++){
    if((*s==X)&&(*(s+1)==Y)&&(free[i])&&(free[i+1])){
      GGX++; free[i]=0; free[i+1]=0; int nuc=-1;
      if(dir){
	nuc=Code_char(*(s+2), atgc, 4); free[i+2]=0;
      }else if(i){
	nuc=Code_char(*(s-1), atgc, 4); free[i-1]=0;
      }
      if((nuc>=0)&&(nuc<4))num[nuc]++;
    }
    s++;
  }
  return(0);
}

int Code_char(char nuc, char *code, int n){
  for(int i=0; i<n; i++)if(nuc==code[i])return(i);
  return(-1);
}

int Get_sequence_chr(char *Seq, long x0, int SIZE,
		 char *chrom, long L, int strand)
{
  int i=0, k;
  // window 2SIZE around center
  long ini=x0-SIZE; if(ini<0)ini=0;
  long end=x0+SIZE; if(end>=L)end=L-1;
  if(strand==0){
    for(k=ini; k<=end; k++){
      Seq[i]=chrom[k]; i++;
    }
  }else{
    for(k=end; k>=ini; k--){
      Seq[i]=Complementary(chrom[k]); i++;
    }
  }
  return(i);
}

char Complementary(char nuc){
  if(nuc=='G'){return('C');}
  else if(nuc=='C'){return('G');}
  else if(nuc=='A'){return('T');}
  else if(nuc=='T'){return('A');}
  else{ return('N');}
}
