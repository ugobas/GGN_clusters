struct frag{
  int chr;
  long x0, ini, end;
  int size;
  char strand;
  float value;
  struct frag *next;
};
