#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <ctype.h>
#include "fragment.h"
#include "AT_skew_aux.h"
//#include "Ori_seq_analysis.h"
//

static int Get_input(char **file_chr, char **chr_name, int NMAX,
		     int *GGNmin, int *LOOP, int argc, char **argv);
static void help(char *CODE);
void Read_name(int *n, char **file, char *PATH, char *string, int nmax);
void Order_peaks(struct frag *frag, int n, struct frag *f0);
void Call_GGN_clusters(int *N_GGN, struct frag *GGN,
		       char *Seq, long L, int chr,
		       int LOOP, int GGNmin, char X, char Y);

// Global variables
char **chromosome; long *Lchr;  int Nchr;


int main(int argc, char **argv)
{
  // Chromosomes
  int NMAX=100; char *file_chr[NMAX], *chr_name[NMAX];

  // Read input names
  int GGNmin=12, LOOP=10;
  Nchr=Get_input(file_chr, chr_name, NMAX, &GGNmin, &LOOP, argc, argv);

  // Read chromosomes
  if(file_chr[0][0]=='\0'){
    printf("ERROR, file with chromosomes must be specified\n");
    exit(8);
  }
  chromosome=malloc(Nchr*sizeof(char *));
  Lchr=malloc(Nchr*sizeof(int)); long Lmax=0;
  for(int chr=0; chr<Nchr; chr++){
    printf("Reading %s\n", file_chr[chr]);
    Lchr[chr]=Read_sequence(&(chromosome[chr]), file_chr[chr]);
    if(Lchr[chr]>Lmax)Lmax=Lchr[chr];
  }

  printf("Calling GGN clusters with max. loop = %d ", LOOP);
  printf("and min. number of GGN = %d\n", GGNmin);

  int N_GGN=0, N_GGN_c=0, N_GGN_max=100000;
  struct frag GGN[N_GGN_max], ini_frag, *f0=&ini_frag;
  for(int chr=0; chr<Nchr; chr++){
    struct frag *GGN_ini=GGN+N_GGN_c; N_GGN=0;
    Call_GGN_clusters(&N_GGN, GGN_ini, chromosome[chr], Lchr[chr],
		      chr+1, LOOP, GGNmin, 'G', 'G');
    Call_GGN_clusters(&N_GGN, GGN_ini, chromosome[chr], Lchr[chr],
		      chr+1, LOOP, GGNmin, 'C', 'C');
    if(N_GGN_c)f0=GGN_ini-1;
    Order_peaks(GGN_ini, N_GGN, f0);
    N_GGN_c+=N_GGN;
    if(N_GGN_c > N_GGN_max){
      printf("ERROR, too many GGN clusters (more than %d)\n", N_GGN_max);
      exit(8);
    }
  }

  char name_file[100]="GGN_clusters";
  sprintf(name_file, "%s_Lmax_%d_GGNmin_%d.bed",
	  name_file, LOOP, GGNmin);
  FILE *file_out=fopen(name_file, "w");
  printf("Writing %d GGN_clusters in %s\n", N_GGN_c, name_file);
  struct frag *f=ini_frag.next;
  for(int i=0; i<N_GGN_c; i++){
    if(f==NULL){printf("%d clusters printed\n", i); break;}
    fprintf(file_out, "%d\t%ld\t%ld\t%.0f\n",
	    f->chr, f->ini, f->end, f->value);
    //printf("%d\t%d\t%ld\n", i, f->chr, f->ini);
    f=f->next;
  }
  fclose(file_out);


  return(0);
}  

static int Get_input(char **file_chr,  char **chr_name, int NMAX,
		     int *GGNmin, int *LOOP, int argc, char **argv)
{
 if(argc<2)help(argv[0]);
  FILE *file_in=fopen(argv[1], "r");
  if(file_in==NULL){
    printf("ERROR, file %s not found\n", argv[1]); exit(8);
  }
  printf("Reading %s\n", argv[1]);

  char string[1000], PATH[80], dumm[80]; PATH[0]='\0';
  int nch=0, rch=-1; // Chromosomes
  int npk=0, rpk=-1; // peaks
  int idum=0;
  while(fgets(string, sizeof(string), file_in)!=NULL){
    if(string[0]=='#'){continue;
    }else if(strncmp(string, "LOOP", 4)==0){
      sscanf(string+5, "%d", LOOP);
    }else if(strncmp(string, "GGNmin", 6)==0){
      sscanf(string+7, "%d", &idum);
      if(idum < 4){
	printf("WARNING, wrong score, using default\n");
      }else{
	*GGNmin=idum;
      }
    }else if(strncmp(string, "CHROMOSOMES", 10)==0){
      printf("Reading chromosome names\n");
      rch=0;
    }else if(strncmp(string, "PEAKS", 5)==0){
      rpk=0;
    }else if(strncmp(string, "END", 3)==0){
      PATH[0]='\0'; 
      rch=-1; rpk=-1;
    }else if(strncmp(string, "DIR", 3)==0){
      char *s=string+4; int k=0;
      while(*s!='\n'){PATH[k]=*s; k++; s++;}
      PATH[k]='\0';
    }else if(rpk>=0){
      sscanf(string, "%s", dumm); npk++;
      //sprintf(file_peak, "%s%s", PATH, dumm);
    }else if(rch>=0){
      chr_name[nch]=malloc(80*sizeof(char));
      sscanf(string, "%s %s", dumm, chr_name[nch]);
      Read_name(&nch, file_chr, PATH, string, NMAX);
    }else if(string[0]!='\n'){
      printf("WARNING, unrecognized command %s\n", string);
    }
  }
  fclose(file_in);
  printf("%d chromosomes\n", nch);
  return(nch);
}

static void help(char *CODE){
  printf("\nPROGRAM %s\n", CODE);
  printf("Author: Ugo Bastolla,\n");
  printf("Centro de Biologia Molecular Severo Ochoa\n");
  printf("(CSIC-UAM), Madrid Spain\n");
  printf("<ubastolla@cbm.uam.es>\n\n");
  printf("Prints sequence of peaks\n");
  printf("FORMAT of the input file:\n");
  printf("LOOP=<>    ! Max. loop length between GGN\n");
  printf("GGNmin=<>  ! Min. number of GGN to call a cluster\n");
  printf("CHROMOSOMES:\n");
  printf("DIR=<>  Directory with chromosome sequences\n");
  printf("<>      Files with chromosomes\n");
  printf("END\n");
  printf("\n");
  exit(8);
}

void Read_name(int *n, char **file, char *PATH, char *string, int nmax)
{
  if(*n>nmax){
    printf("ERROR, too many input files, maximum %d\n", nmax);
    exit(8);
  }
  char name[200]; sscanf(string, "%s", name);
  file[*n]=malloc(200*sizeof(char));
  sprintf(file[*n], "%s%s", PATH, name);
  (*n)++;
}

void Call_GGN_clusters(int *N_GGN, struct frag *GGN,
		       char *Seq, long L, int chr,
		       int LOOP, int GGNmin, char X, char Y)
{
  char *s=Seq; struct frag *f=GGN+(*N_GGN);
  int l=0, GG=0; long ini=0;
  int free[L]; for(long i=0; i<L; i++)free[i]=1;
  for(long i=0; i<L; i++){
    if((free[i])&&(free[i+1])&&(*s==X)&&(*(s+1)==Y)){
      if(GG==0)ini=i; GG++; l=0;
      free[i]=0; free[i+1]=0; free[i+2]=0; 
    }
    if(free[i])l++; // increase loop length
    if(l>LOOP){ // End of cluster
      if(GG>=GGNmin){
	f->chr=chr; f->ini=ini; f->end=i; f->value=GG;
	f++; (*N_GGN)++;
      } 
      GG=0; l=0;
    }
    s++;
  }
}

void Order_peaks(struct frag *frag, int n, struct frag *f0)
{
  f0->next=frag;
  struct frag *f1=frag, *f2=f1+1;
  for(int i=0; i<n; i++){f1->next=NULL; f1++;}
  f1=frag;
  for(int i=1; i<n; i++){
    if(f1->end >= f2->ini){
      f1=f0->next;
      if(f1->end >= f2->ini){ // First fragment of chromosome
	/*printf("First peak chr %d: %ld -> ", f1->chr, f1->ini);
	  printf("%d %ld %ld\n", f2->chr, f2->ini, f2->end);*/
	f0->next=f2; f2->next=f1; f2++; continue;
      }
    } 
    while((f1->next)&&(f1->next->end < f2->ini))f1=f1->next;
    f2->next=f1->next; f1->next=f2; 
    f1=f2; f2++;
  }
}
