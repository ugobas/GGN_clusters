//int STANDARD;

long Read_sequence(char **seq, char *file_chr);
char Maiuscule(char s);
int Count_char(char *string);
int Copy_char(char *string, char *seq);

void Skew_comp(float *AT_skew, int *ATS_win,
	       float *GC_skew, int *GCS_win,
	       float *GA_skew, int *GAS_win,
	       float *GC_local,int *GCL_win,
	       char *seq, long L, long Win_ini,
	       long Win_max, float IND_FRAC,
	       float GC, float dGC, float dGCS, float dATS,
	       long site);
void Print_skew(float *score, int *window, long L, char *filename,
		int WINOUT, char *lab);
void Print_skew_bed(float *score, int *window, long L, char *filename,
		    int WINOUT, char *lab, char *chr);
void Print_skew_wig(float *score, int *window, long L, char *filename,
		    int WINOUT, char *name, char *chr);
float GC_ave(char *seq, long L);
float Ave_nuc(char *seq, long L, char nuc);
long Find_motif(long *list, char *motif, char *seq, long L);
void Print_motif(long *list, long Nmot, char *filename, int cr,
		 char *motif, int len);
void Print_GC(char *seq, long L, char *filename, int WINOUT);
void Print_nuc(char *seq, long L, char *filename, int WINOUT, char *nuc);
int Count_nuc(char *Seq, int L, char x);
int Count_XYN(char *Seq, int len, char X, char Y);
int Count_XYN_num(int *num, char *atgc, char *Seq, int len,
		  char X, char Y, int dir);
int Get_sequence_chr(char *Seq, long x0, int SIZE,
		     char *chrom, long L, int strand);
